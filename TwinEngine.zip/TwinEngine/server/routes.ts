import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertSimulationScenarioSchema, 
  hcpFilterSchema,
  createStimuliRequestSchema,
  createCounterfactualRequestSchema,
  nlQueryRequestSchema,
  recordOutcomeRequestSchema,
  runEvaluationRequestSchema,
} from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed database on startup
  try {
    await storage.seedHcpData(100);
  } catch (error) {
    console.error("Error seeding database:", error);
  }

  // HCP endpoints
  app.get("/api/hcps", async (req, res) => {
    try {
      const hcps = await storage.getAllHcps();
      
      // Log view action
      await storage.logAction({
        action: "view",
        entityType: "hcp_list",
        details: { count: hcps.length },
      });
      
      res.json(hcps);
    } catch (error) {
      console.error("Error fetching HCPs:", error);
      res.status(500).json({ error: "Failed to fetch HCPs" });
    }
  });

  app.get("/api/hcps/:id", async (req, res) => {
    try {
      const hcp = await storage.getHcpById(req.params.id);
      if (!hcp) {
        return res.status(404).json({ error: "HCP not found" });
      }
      
      // Log view action
      await storage.logAction({
        action: "view",
        entityType: "hcp_profile",
        entityId: hcp.id,
        details: { npi: hcp.npi, name: `${hcp.firstName} ${hcp.lastName}` },
      });
      
      res.json(hcp);
    } catch (error) {
      console.error("Error fetching HCP:", error);
      res.status(500).json({ error: "Failed to fetch HCP" });
    }
  });

  app.get("/api/hcps/npi/:npi", async (req, res) => {
    try {
      const hcp = await storage.getHcpByNpi(req.params.npi);
      if (!hcp) {
        return res.status(404).json({ error: "HCP not found" });
      }
      res.json(hcp);
    } catch (error) {
      console.error("Error fetching HCP by NPI:", error);
      res.status(500).json({ error: "Failed to fetch HCP" });
    }
  });

  app.post("/api/hcps/filter", async (req, res) => {
    try {
      const parseResult = hcpFilterSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ error: "Invalid filter parameters" });
      }
      const hcps = await storage.filterHcps(parseResult.data);
      res.json(hcps);
    } catch (error) {
      console.error("Error filtering HCPs:", error);
      res.status(500).json({ error: "Failed to filter HCPs" });
    }
  });

  // Lookalike/similar HCPs endpoint
  app.get("/api/hcps/:id/similar", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const similarHcps = await storage.findSimilarHcps(req.params.id, limit);
      
      // Log lookalike search
      await storage.logAction({
        action: "lookalike_search",
        entityType: "hcp_profile",
        entityId: req.params.id,
        details: { resultCount: similarHcps.length, limit },
      });
      
      res.json(similarHcps);
    } catch (error) {
      console.error("Error finding similar HCPs:", error);
      res.status(500).json({ error: "Failed to find similar HCPs" });
    }
  });

  // Simulation endpoints
  app.post("/api/simulations/run", async (req, res) => {
    try {
      const parseResult = insertSimulationScenarioSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Invalid simulation parameters",
          details: parseResult.error.errors 
        });
      }
      const result = await storage.createSimulation(parseResult.data);
      res.json(result);
    } catch (error) {
      console.error("Error running simulation:", error);
      res.status(500).json({ error: "Failed to run simulation" });
    }
  });

  app.get("/api/simulations/history", async (req, res) => {
    try {
      const history = await storage.getSimulationHistory();
      res.json(history);
    } catch (error) {
      console.error("Error fetching simulation history:", error);
      res.status(500).json({ error: "Failed to fetch simulation history" });
    }
  });

  app.get("/api/simulations/:id", async (req, res) => {
    try {
      const simulation = await storage.getSimulationById(req.params.id);
      if (!simulation) {
        return res.status(404).json({ error: "Simulation not found" });
      }
      res.json(simulation);
    } catch (error) {
      console.error("Error fetching simulation:", error);
      res.status(500).json({ error: "Failed to fetch simulation" });
    }
  });

  // Dashboard endpoints
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ error: "Failed to fetch dashboard metrics" });
    }
  });

  // Audit log endpoints
  app.get("/api/audit-logs", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const logs = await storage.getAuditLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching audit logs:", error);
      res.status(500).json({ error: "Failed to fetch audit logs" });
    }
  });

  // Export endpoint (for governance/compliance)
  app.get("/api/export/hcps", async (req, res) => {
    try {
      const hcps = await storage.getAllHcps();
      
      // Log export action
      await storage.logAction({
        action: "export",
        entityType: "hcp_data",
        details: { count: hcps.length, format: "json" },
      });
      
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Content-Disposition", "attachment; filename=hcp-export.json");
      res.json(hcps);
    } catch (error) {
      console.error("Error exporting HCPs:", error);
      res.status(500).json({ error: "Failed to export HCP data" });
    }
  });

  // ============ Stimuli Impact Prediction Endpoints ============

  app.post("/api/stimuli", async (req, res) => {
    try {
      const parseResult = createStimuliRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Invalid stimuli parameters",
          details: parseResult.error.errors 
        });
      }
      const event = await storage.createStimuliEvent(parseResult.data);
      res.json(event);
    } catch (error) {
      console.error("Error creating stimuli event:", error);
      res.status(500).json({ error: "Failed to create stimuli event" });
    }
  });

  app.get("/api/stimuli", async (req, res) => {
    try {
      const hcpId = req.query.hcpId as string | undefined;
      const limit = parseInt(req.query.limit as string) || 50;
      const events = await storage.getStimuliEvents(hcpId, limit);
      res.json(events);
    } catch (error) {
      console.error("Error fetching stimuli events:", error);
      res.status(500).json({ error: "Failed to fetch stimuli events" });
    }
  });

  app.patch("/api/stimuli/:id/outcome", async (req, res) => {
    try {
      const { actualEngagementDelta, actualConversionDelta } = req.body;
      if (typeof actualEngagementDelta !== "number" || typeof actualConversionDelta !== "number") {
        return res.status(400).json({ error: "Invalid outcome parameters" });
      }
      const event = await storage.recordStimuliOutcome(
        req.params.id,
        actualEngagementDelta,
        actualConversionDelta
      );
      if (!event) {
        return res.status(404).json({ error: "Stimuli event not found" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error recording stimuli outcome:", error);
      res.status(500).json({ error: "Failed to record outcome" });
    }
  });

  // ============ Counterfactual Backtesting Endpoints ============

  app.post("/api/counterfactuals", async (req, res) => {
    try {
      const parseResult = createCounterfactualRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Invalid counterfactual parameters",
          details: parseResult.error.errors 
        });
      }
      const scenario = await storage.createCounterfactual(parseResult.data);
      res.json(scenario);
    } catch (error) {
      console.error("Error creating counterfactual:", error);
      res.status(500).json({ error: "Failed to create counterfactual analysis" });
    }
  });

  app.get("/api/counterfactuals", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const scenarios = await storage.getCounterfactualScenarios(limit);
      res.json(scenarios);
    } catch (error) {
      console.error("Error fetching counterfactuals:", error);
      res.status(500).json({ error: "Failed to fetch counterfactual scenarios" });
    }
  });

  app.get("/api/counterfactuals/:id", async (req, res) => {
    try {
      const scenario = await storage.getCounterfactualById(req.params.id);
      if (!scenario) {
        return res.status(404).json({ error: "Counterfactual scenario not found" });
      }
      res.json(scenario);
    } catch (error) {
      console.error("Error fetching counterfactual:", error);
      res.status(500).json({ error: "Failed to fetch counterfactual scenario" });
    }
  });

  // ============ Natural Language Query Endpoints ============

  app.post("/api/nl-query", async (req, res) => {
    try {
      const parseResult = nlQueryRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Invalid query parameters",
          details: parseResult.error.errors 
        });
      }
      const response = await storage.processNLQuery(parseResult.data);
      res.json(response);
    } catch (error) {
      console.error("Error processing NL query:", error);
      res.status(500).json({ error: "Failed to process natural language query" });
    }
  });

  app.get("/api/nl-query/history", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const history = await storage.getNLQueryHistory(limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching NL query history:", error);
      res.status(500).json({ error: "Failed to fetch query history" });
    }
  });

  // ============ Model Evaluation & Closed-Loop Learning Endpoints ============

  app.post("/api/stimuli/:id/outcome", async (req, res) => {
    try {
      const parseResult = recordOutcomeRequestSchema.safeParse({
        ...req.body,
        stimuliEventId: req.params.id,
      });
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Invalid outcome parameters",
          details: parseResult.error.errors 
        });
      }
      const event = await storage.recordOutcome(parseResult.data);
      if (!event) {
        return res.status(404).json({ error: "Stimuli event not found" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error recording outcome:", error);
      res.status(500).json({ error: "Failed to record outcome" });
    }
  });

  app.post("/api/model-evaluation", async (req, res) => {
    try {
      const parseResult = runEvaluationRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Invalid evaluation parameters",
          details: parseResult.error.errors 
        });
      }
      const evaluation = await storage.runModelEvaluation(parseResult.data);
      res.json(evaluation);
    } catch (error) {
      console.error("Error running model evaluation:", error);
      res.status(500).json({ error: "Failed to run model evaluation" });
    }
  });

  app.get("/api/model-evaluation", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const evaluations = await storage.getModelEvaluations(limit);
      res.json(evaluations);
    } catch (error) {
      console.error("Error fetching model evaluations:", error);
      res.status(500).json({ error: "Failed to fetch model evaluations" });
    }
  });

  app.get("/api/model-health", async (req, res) => {
    try {
      const summary = await storage.getModelHealthSummary();
      res.json(summary);
    } catch (error) {
      console.error("Error fetching model health:", error);
      res.status(500).json({ error: "Failed to fetch model health summary" });
    }
  });

  return httpServer;
}
